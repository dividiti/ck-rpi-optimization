#include "rar.hpp"



#ifndef RARDLL
const wchar *St(MSGID StringId)
{
  return StringId;
}
#endif

