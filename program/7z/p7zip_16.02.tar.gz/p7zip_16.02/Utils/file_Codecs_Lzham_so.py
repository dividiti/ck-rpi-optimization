
files_c=[
 'C/Alloc.c',
]

files_cpp=[
 'CPP/7zip/Common/StreamUtils.cpp',
 'CPP/7zip/Compress/CodecExports.cpp',
 'CPP/7zip/Compress/DllExportsCompress.cpp',
 'CPP/7zip/Compress/Lzham/LzhamRegister.cpp',
 'CPP/Common/MyWindows.cpp',
 'CPP/Windows/System.cpp',

 # lzhamcomp
 'CPP/7zip/Compress/Lzham/lzhamcomp/lzham_lzbase.cpp',
 'CPP/7zip/Compress/Lzham/lzhamcomp/lzham_lzcomp.cpp',
 'CPP/7zip/Compress/Lzham/lzhamcomp/lzham_lzcomp_internal.cpp',
 'CPP/7zip/Compress/Lzham/lzhamcomp/lzham_lzcomp_state.cpp',
 'CPP/7zip/Compress/Lzham/lzhamcomp/lzham_match_accel.cpp',
 'CPP/7zip/Compress/Lzham/lzhamcomp/lzham_pthreads_threading.cpp',

 # lzhamdecomp
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_assert.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_checksum.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_huffman_codes.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_lzdecomp.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_lzdecompbase.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_mem.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_platform.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_prefix_coding.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_symbol_codec.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_timer.cpp',
 'CPP/7zip/Compress/Lzham/lzhamdecomp/lzham_vector.cpp', 
 
 # lzhamlib
 'CPP/7zip/Compress/Lzham/lzhamlib/lzham_lib.cpp', 
]


