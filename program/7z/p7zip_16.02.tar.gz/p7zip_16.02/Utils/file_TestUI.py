
files_c=[
 'C/Threads.c',
]

files_cpp=[
 'CPP/7zip/TEST/TestUI/TestUI.cpp',
 'CPP/7zip/UI/FileManager/PasswordDialog.cpp',
 'CPP/7zip/UI/FileManager/PasswordDialog_rc.cpp',
 'CPP/Common/MyString.cpp',
 'CPP/Common/MyWindows.cpp',
 'CPP/Windows/Control/Controls.cpp',
 'CPP/Windows/Control/Dialog.cpp',
 'CPP/Windows/Window.cpp',
]

